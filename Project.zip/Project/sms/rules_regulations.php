<html>
   <body>
      <link rel="stylesheet" href="css/style.css" type="text/css"/>
    <div class="header">
  <h1><center>SOCIETY MANAGEMENT SYSTEM</center></h1>
</div>
	    <div id="topnav">
        <div class="header" style="text-align: center;background:rgba(221, 223, 0, 0.4) ">
			<a class="active" href="user_page.php">My profile</a>&nbsp&nbsp
            <a href="pay_maintenance.php">Pay maintenance</a>&nbsp&nbsp
			<a href="place_complain.php">Place Complain</a>&nbsp&nbsp
			<a href="rules_regulations.php">Rules/Regulations</a>&nbsp&nbsp
			<a href="domestic_suppliers.php">Domestic Suppliers</a>&nbsp&nbsp
			<a href="notices.php">Notices</a>
		    <a href="logout.php" style="float:right">Logout</a>
	    </div>
		<section id="section">
        <div  align="left" style="background: rgba(221, 223, 226, 1)"> 
			  <li>No member can occupy the area near their front doors, corridors, passage for their personal usage.</li><br>
			  <li>Owners who want to give their flats on rent should take proper permission from the authorized person of the society.</li><br>
			  <li>Every member of the society should park their vehicles in their respective allotted parking spaces only.</li><br>
			  <li>Smoking in lobbies, passage is not allowed. If any irresponsible person is found smoking in the no smoking zone, he/she shall be charged 
			      with penalty.</li><br>
			</ul>
      	</section>

		<div class="footer">
  <p></p>
</div>
   </body>
</html>