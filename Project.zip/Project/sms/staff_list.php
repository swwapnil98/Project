<?php
     include('config.php');
	 session_start();
	 $Email = $_SESSION['Email_Id'];		
			
	 if(!$Email)
		{
		  header("Location:index.php");
		}
?>

<html>
  <body id="adminpage">
      <link rel="stylesheet" href="css/style.css" type="text/css"/>
        <div class="header" style="text-align: center;background:rgba(221, 223, 0, 0.4) ">
           <h1><center>SOCIETY MANAGEMENT SYSTEM</center></h1>
        </div>
		<section> 
	        <div class="guest">
			  <form method="post">
				<h2 style="color:black;">Staff List:</h2>
                <div  align="center" style="background: rgba(221, 223, 226, 1)">      
	                 <?php
			
			if(mysqli_connect_errno())
			  {
					echo "Failed to connect to MySQL: " . mysqli_connect_error();
			  }
			else
				{
					$result = mysqli_query($dbConn,"SELECT * FROM staff_entry");
					echo "<table border='4' width='100%' cellspacing='4' id='user'>
					<tr>
					<th>Name</th>
					<th>Staff_for</th>
					<th>Date</th>
					<th>Check_in</th>
					<th>Check_out</th>
					<th>Update</th>
					</tr>";
						while($row = mysqli_fetch_array($result))
						  {
							echo '<tr>
							<td align="center">' . $row['Name'] . '</td>
							<td align="center">' . $row['Staff_for'] . '</td>
							<td align="center">' . $row['Date'] . '</td>
							<td align="center">' . $row['Check_in'] . '</td>
							<td align="center">'. $row['Check_out'] . '</td>
							<td align="center"><a href="staff_update.php?id=' .$row['Id'] . '" style="color:black;">Update</a>
							</tr>';
						  }
							echo "</table>";
				}
						
	    ?>
						<p><font size="4px" color="black">Go to <a href="gatekeeper.php" style="color:black;" >homepage</a><br><br>
						
	          </div>
			  </form>
			 
</div>
	    </section>
	
</div>

  </body>
</html>