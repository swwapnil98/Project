<html>
   <body>
      <link rel="stylesheet" href="css/style.css" type="text/css"/>
    <div class="header">
  <h1><center>SOCIETY MANAGEMENT SYSTEM</center></h1>
</div>
	    <div id="topnav">
        <div class="header" style="text-align: center;background:rgba(221, 223, 0, 0.4) ">
			<a href="admin_page.php" class="btn">Member Details</a>
			<a href="guest_details.php" class="btn">Guest Entries</a>
			<a href="staff_details.php" class="btn">Staff Details</a>
			<a href="staff_entries.php" class="btn">Staff Entries</a>
			<a href="maintenance.php" class="btn">Maintenance</a>
			<a href="see_complains.php" class="btn">Complaints</a>
			<a href="post_rules.php" class="btn">Rules/Regulations</a>
			<a href="post_notice.php" class="btn">Notices</a>
		    <a href="logout.php"  class="btn" style="float:right">Logout</a>
	    </div>
		<section id="section">		
        <div  align="left" style="background: rgba(221, 223, 226, 1)"> 
		    <ul>
			  <li>No member can occupy the area near their front doors, corridors, passage for their personal usage.</li><br>
			  <li>Owners who want to give their flats on rent should take proper permission from the authorized person of the society. </li><br>
	          <li>Salesmen, vendors or any other sellers are not allowed to enter the premises. Owners residing are not allowed to rent their flats for any 
			      commercial use as this might create trouble to other society members.</li><br>
			  <li>Smoking in lobbies, passage is not allowed. If any irresponsible person is found smoking in the no smoking zone, he/she shall be charged 
			      with penalty.</li><br>
			</ul>
     
	    </section>
	<div class="footer">
  <p></p>
</div>
  </body>
</html>