<html>
   <body>
      <link rel="stylesheet" href="css/style.css" type="text/css"/>
    <div class="header">
  <h1>SOCIETY MANAGEMENT SYSTEM</h1>
</div>
	    <div id="topnav">
			<a class="active" href="admin_page.php">Member Details</a>
			<a href="guest_details.php">Guest Details</a>
			<a href="see_maintenance.php">Maintenance</a>
			<a href="see_complains.php">Complaints</a>
			<a href="post_rules.php">Rules/Regulations</a>
			<a href="post_suppliers.php">Domestic Suppliers</a>
			<a href="post_notice.php">Notices</a>
		    <a href="logout.php" style="float:right">Logout</a>
	    </div>
		<section id="section"> 
	    
		</section>
	<div class="footer">
  <p>Copyright 2019 | All Rights Reserved</p>
</div>
  </body>
</html>
