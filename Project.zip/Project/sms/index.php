<?php
   
    include('config.php');
	session_start();
    if(isset($_POST['submit']))
		{		
			$Email_Id=$_POST['Email_Id'];
			$password = $_POST['password'];
			   
			$search_query=mysqli_query($dbConn,"select * from register where Email_Id='$Email_Id' and password='$password'");
			$_SESSION['Email_Id']=$Email_Id;	
				
			if($Email_Id=="Admin@gmail.com" && $password=="admin")
			{
			   header("Location: admin_page.php");
			}
			elseif(mysqli_num_rows($search_query) ==1)
			{
				header("Location: user_page.php");
			}
			elseif($Email_Id=="gatekeeper@gmail.com" && $password=="gatekeeper")
			{
			   header("Location: gatekeeper.php");
			}
			else
			{
			  echo "<script>alert('incorrect')</script>";
			}		
		}
?>


<html>
<head>
</head>
<body>
<link rel="stylesheet" href="css/style.css" type="text/css"/>
<div class="header" style="text-align: center;background:rgba(221, 223, 0, 0.4) ">
  <h1>SOCIETY MANAGEMENT SYSTEM</h1>
</div>


<div class="row" align="center">
   <div >
    <ul>
      <li><p style="color:black;">The perfect solution to make living in an society complex a pleasant and convenient experience for the residents, the managing committee members <br> and the security staff.</p></li>
   </ul>
</div>
   >
   <div align="center" style="margin-left:25%"  style="background: rgba(221, 223, 226, 1)">
   <img src="images/app.png" align="center" id="img" height=200 width=500/>
  </div>
</div>

<div class="footer" style="margin-left:24.5%">
  <p> 2020-2021 </p>
</div>

	 <div  align="center" style="background: rgba(221, 223, 226, 1)"> 

	 <form action="" method="POST">
		 <h2 style="color:black;">Login:</h2>
          <table>	
			<label for="email">Email:</label><br>
			<input type="email" name="Email_Id" id="email"  placeholder="Enter your Email_ID" required / ><br><br>
			<label for="password">Password:</label><br>
			<input type="password" placeholder="Password" id="password" name="password" required / ><br><br>
			<input type="submit" id="submit" name="submit" value="Login"><br><br><br>
		  </table>
	 </form>
  </div>
  </div>

  

</body>
</html>
