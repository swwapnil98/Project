
<?php

session_start();

header('location:index.php');
$con = mysqli_connect('localhost','root');
if($con){
	echo" connection successful";
}else{
	echo " no connection"; 
}

mysqli_select_db($con, 'carrental');
$email=$_POST['email'];
	$password=$_POST['password'];
    $address=$_POST['address'];
    $address2=$_POST['address2'];
    $mobilenumber=$_POST['mobilenumber'];
    $city=$_POST['city'];
    $zip=$_POST['zip'];


$q = " select * from users  where email = '$email' && password = '$password' ";

$result = mysqli_query($con, $q);

$num = mysqli_num_rows($result);

if($num == 1){
	echo" duplicate data ";
}else{

	$qy= " insert into users (
email,password,address,address2,mobilenumber,city,zip) values ('$email','$password','$address','$address2','$mobilenumber','$city','$zip') ";
	mysqli_query($con, $qy);
	
}



?>

