-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 22, 2023 at 04:13 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carrental`
--

-- --------------------------------------------------------

--
-- Table structure for table `findcar1`
--

CREATE TABLE `findcar1` (
  `email` varchar(30) NOT NULL,
  `pdate` date NOT NULL,
  `ddate` date NOT NULL,
  `daddress` varchar(30) NOT NULL,
  `paddress` varchar(30) NOT NULL,
  `book` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `findcar1`
--

INSERT INTO `findcar1` (`email`, `pdate`, `ddate`, `daddress`, `paddress`, `book`) VALUES
('swapnil@yahoo.com', '2019-09-06', '2019-09-15', 'Panvel', 'Uran', 'corolla'),
('swapnil@yahoo.com', '2019-09-06', '2019-09-12', 'mahabaleshwar', 'Uran', 'Ertiga'),
('swapnil@yahoo.com', '2019-09-19', '2019-09-20', 'panvel', 'Uran', 'Amaze'),
('', '0000-00-00', '0000-00-00', '', '', ''),
('swapnil@yahoo.com', '2019-09-12', '2019-09-28', 'Mirchi Galli', 'Koliwada', 'Desire'),
('test@test', '2019-09-11', '2019-09-19', 'California', 'New York', 'Ertiga'),
('jayesh@gmail.com', '2019-09-15', '2019-09-17', 'belapur', 'panvel', 'Toyota cor'),
('shekharchilwant2001@gmail.com', '2019-09-16', '2019-09-17', 'panval ', 'panvel', 'Toyota cor'),
('sanket@gmail.com', '2019-09-18', '2019-09-19', 'belapur', 'panvel', 'Swift Desi'),
('sanket@gmail.com', '0000-00-00', '0000-00-00', '', '', ''),
('sanket@gmail.com', '0000-00-00', '0000-00-00', '', '', ''),
('sanket@gmail.com', '0000-00-00', '0000-00-00', '', '', ''),
('sanket@gmail.com', '0000-00-00', '0000-00-00', '', '', ''),
('swapnilchilwant01@gmail.com', '2019-09-04', '2019-09-06', 'belapur', 'Panvel bus stand', 'Suziki Ert'),
('swapnilchilwant156@gmail.com', '2019-09-24', '2019-09-25', 'belapur', 'Panvel bus stand', 'Suziki Ert'),
('shekharchilwant2001@gmail.com', '2019-09-29', '2019-10-01', 'belapur', 'Panvel bus stand', 'Toyota cor'),
('shekharchilwant2001@gmail.com', '2019-09-29', '2019-09-30', 'belapur', 'panvel', 'Swift Desi'),
('varunpatil@gmail.com', '2019-09-12', '2019-09-27', 'belapur', 'panvel', 'Suziki Ert'),
('rani1506@gmail.com', '2020-01-03', '2020-01-05', 'new panvel', 'panvel', 'Toyota cor'),
('abcd@gmail.com', '2020-01-07', '2020-01-08', 'kharghar', 'panvel', 'Suziki Ert'),
('shreya@gmail.com', '2020-07-24', '2020-07-25', 'morave', 'old panvel', 'Swift Desi'),
('swapnilchilwant@gmail.com', '2021-02-15', '2021-02-16', 'kharghar', 'panvel station', 'Suziki Ert'),
('shekhar@gmail.com', '2021-07-08', '2021-07-09', 'karanjade ', 'panvel', ''),
('shekhar@gmail.com', '0000-00-00', '0000-00-00', '', '', ''),
('shekhar@gmail.com', '0000-00-00', '0000-00-00', '', '', 'Swift Desi'),
('vilas@gmail.com', '2021-08-05', '2021-08-27', 'panevl 2', 'panvel bus depo', 'Suziki Ert'),
('shekharchilwant2001@gmail.com', '2021-09-08', '2021-10-03', 'dad', 'adad', 'Suziki Ert'),
('artboy@gmail.com', '2021-10-26', '2021-10-27', 'Belapur', 'Panvel railway station', 'Swift Desi'),
('abc@gmail.com', '0000-00-00', '0000-00-00', '', '', 'Toyota cor'),
('anilpatil@gmail.com', '2020-06-14', '2000-05-15', 'dllsfh', 'jdkkjg', 'Toyota cor'),
('yash@gmail.com', '2022-01-05', '2022-01-17', 'panvel', 'panvel', 'Swift Desi'),
('shekhar@gmail.com', '2022-03-10', '2022-03-03', 'dada', 'adad', 'Swift Desi'),
('yash12@gmail.com', '2022-03-18', '2022-03-16', 'MOHO', 'PANVEL', 'Swift Desi');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `email` varchar(30) NOT NULL,
  `password` varchar(16) NOT NULL,
  `address` varchar(50) NOT NULL,
  `address2` varchar(50) NOT NULL,
  `mobilenumber` int(10) NOT NULL,
  `city` varchar(30) NOT NULL,
  `zip` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`email`, `password`, `address`, `address2`, `mobilenumber`, `city`, `zip`) VALUES
('test@test', 'test', 'test', 'test', 1234, 'panvel', 410206),
('rahul@gmail.com', 'rahul', 'a', 'aa', 123456789, 'moho', 410207),
('rajesh@gmail.com', 'rajesh', 'sadkjlfj', 'fdskjla', 23432, 'sdflkja', 34234),
('swapnil@yahoo.com', 'swapnil', 'Karnjade', 'Panvel', 2147483647, 'Panvel', 410206),
('jayesh@gmail.com', 'jayesh', 'panvel', 'karnjade', 2147483647, '077B256B-6CDE-4CCE-B19A-2214B9', 410206),
('shekharchilwant2001@gmail.com', 'shekhar', 'at.moho post.chikhale ta.panvel dist raigad', '', 2147483647, 'panvel  ', 410206),
('shekharchilwant2001@gmail.com', '', 'at.moho post.chikhale ta.panvel dist raigad', '', 2147483647, 'panvel  ', 410206),
('sanket@gmail.com', 'sanket', 'old panvel', 'khanda colony', 2147483647, 'panvel', 410206),
('swapnilchilwant01@gmail.com', 'swapnil01', 'old panvel', 'old panvel', 123456789, 'panvel', 410206),
('swapnilchilwant156@gmail.com', 'swapnil156', 'panvel', '', 0, '', 0),
('swapnilchilwant156@gmail.com', '', 'at.moho post.chikhale ta.panvel dist raigad', 'panvel', 123456789, 'panvel', 410206),
('varunpatil@gmail.com', 'varun', 'khanda colony', 'panvel', 2147483647, 'panvel', 410206),
('rani1506@gmail.com', 'rani1506', 'moho', 'moho', 1425522552, 'panvel', 456),
('bro@gmail.com', 'bro123', 'dfds', 'sdf', 2147483647, 'sf', 561),
('abcd@gmail.com', 'abcd123', 'dsd', 'asdf', 2147483647, 'sdf', 1234),
('swapnilchilwant09@gmail.com', 'swapnil', 'as', 'as', 2147483647, 'sdf', 12),
('', '', '', '', 0, '', 0),
('swapnil@gmail.com', 'swapnil', 'dsaa', 'sdf', 1234567890, 'sdjfl', 412145),
('swapnilc@gmail.com', 'swapnilc', 'sfds', 'sgfv', 1236547890, 'sfgsdf', 147852),
('shreya@gmail.com', 'shreya', 'sdf', 'sfds', 1236547890, 'sfsdf', 147025),
('shekhchilli@gmail.com', '12345678', 'moho ', 'pnavel', 123456789, 'panvel', 410206),
('swapnilchilwant@gmail.com', '123456789', 'o9jmion', 'jhnksad', 123456789, ' mbn ', 401206),
('shekhar@gmail.com', '', '', '', 0, '', 0),
('shekhar@gmail.com', 'shekhar', 'karanjade', 'kabir palace', 1454245, 'jsdasi', 0),
('shekhar@gmail.com', '1234', 'sadd', 'asd', 59585452, 'sda', 0),
('dfsf@gmail.com', 'sad', 'asda', 'sad', 0, 'sa', 0),
('shekhar@gmail.com', '123', 'gfgd', 'dfgsg', 4574854, 'dgas', 0),
('vilas@gmail.com', '1234', 'mane park view ', '5dadadasd', 85465464, 'panvel', 410206),
('sd@gmail.com', 'fmail.com', 'ds', 'sdf', 65654, '486545', 654),
('swap@gmail.com', '123456', 'sdfjj', 'asdf', 2147483647, '6546', 654646),
('swap@gmail.com', '123456', 'sdfjj', 'asdf', 2147483647, '6546', 654646),
('swapnil@gmail.com', '123456789', 'swapnil1', 'swapnilc', 2147483647, '12365478', 0),
('artboy@gmail.com', 'swapnil', 'panvel', 'panvel', 1234567890, 'Old panvel', 410206),
('kabir@mail.com', 'kabir', 'sjld', 'ldjlj', 1234567890, '1453', 3244),
('dinesh@gmail.com', '123456', 'moho', 'moho', 1234567890, '145486', 140582),
('abc@gmail.com', 'abc123', 'adf', 'sfdsd', 1234567890, 'dsdfse', 14512),
('anilpatil@gmail.com', 'anilpatil', 'moho', 'moho', 1234567890, 'panvel', 415415),
('yash@gmail.com', 'yash', 'panvael', 'marina', 54721657, 'panvel', 55451),
('yash12@gmail.com', 'yash', 'panvel', 'oswal plaza=4', 2147483647, 'panvel', 410206);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
