<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/perdetail.css">
</head>
<body>
<header>
	<div class="title">
		<h1><center>personal detail</center></h1>
		<hr>
		<div class="side"></div>
	<div id="main">
		<form method="post" action="form">
		Name :<input type="name" name="name" placeholder="Enter your name"><br><br> 	
       	</form>
		
		
</header>
</body>
</html>