
<?php

session_start();
if(!isset($_SESSION['email'])){
header('location:index.php');
}


?>

<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

	<title></title>
</head>
<body>
<header><h1><center>User detail</center></h1>
<strong> Select Designation : </strong> 
<form method="POST">
 <select name="semail"> 
  <option>select email</option>
              <?php
      $con = mysqli_connect('localhost','root');
if($con){
  echo" connection successful";
}else{
  echo " no connection"; 
}

mysqli_select_db($con, 'carrental');
          

          $dd_res=mysqli_query($con,"select email from users");
          while($r=mysqli_fetch_row($dd_res))
          { 
                echo "<option value='$r[0]'> $r[0] </option>";
          }
      ?>
 </select> <input type="submit" value="show" name="submit">
	</form>
</div>
</header>

<?php 
  if($_SERVER['REQUEST_METHOD'] == "POST")
  {
$semail=$_POST['semail'];

$sql = "SELECT * FROM users where email='$semail'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
// output data of each row
echo "<table border='2' cellpadding='19'>";
echo "<tr> 
<th>email</th><th>password</th><th>mobile number</th><th>address</th><th>address2</th><th>city</th><th>zip</th></tr>";

while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["email"]. "</td><td>" . $row["password"] . "</td><td>"
. $row["mobilenumber"]. "</td><td>" . $row["address"]. "</td><td>" . $row["address2"]. "</td><td>" . $row["city"]. "</td><td>" . $row["zip"]. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }

}
?>
</table>
<br>
<?php 
  if($_SERVER['REQUEST_METHOD'] == "POST")
  {
$semail=$_POST['semail'];

$sql = "SELECT * FROM findcar1 where email='$semail'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
// output data of each row
echo "<table border='2' cellpadding='19'>";
echo "<tr> 
<th>pickup date</th><th>drop date</th><th>pickup address</th><th>drop address</th><th>selected car </th>";

while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["pdate"]. "</td><td>" . $row["ddate"] . "</td><td>"
. $row["paddress"]. "</td><td>" . $row["daddress"]. "</td><td>" . $row["book"]. "</td></tr>";
}
echo "</table>";
} else { echo "Not booked any car"; }
$con->close();
}
?>
</table>
<br>
<br>
<br>
<br>
<form action="logout.php"><input type="submit" value="logout" name="logout" class="btn btn-primary"></form></center>



</body>
</html>

