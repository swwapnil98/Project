<?php

session_start();
if(!isset($_SESSION['email'])){
header('location:index.php');
}


?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<div style="margin-top: 300px; color: red; ">
<center><h1>Thank you for Registering we will contact you as soon as possible !</h1><br><form action="logout.php"><input type="submit" value="ok" name="ok" class="btn btn-primary"></form></center>
</div>
<?php 

session_destroy();
 ?>


</body>
</html>