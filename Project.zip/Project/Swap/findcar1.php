
<?php

session_start();

$con = mysqli_connect('localhost','root');
if($con){
	echo" connection successful";
}else{
	echo " no connection"; 
}

mysqli_select_db($con, 'carrental');
$email=$_SESSION['email'];
	$paddress=$_POST['paddress'];
    $daddress=$_POST['daddress'];
    $pdate=$_POST['pdate'];
    $ddate=$_POST['ddate'];
    $book=$_POST['book'];
    
{

	$qy= " insert into findcar1 (
email,paddress,daddress,pdate,ddate,book) values ('$email','$paddress','$daddress','$pdate','$ddate','$book') ";
	mysqli_query($con, $qy);
	
header('location:findcar2.php');
	
}



?>

