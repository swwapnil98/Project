<?php

session_start();


$con = mysqli_connect('localhost','root');
if($con){
	echo" connection successful";
}else{
	echo " no connection"; 
}

mysqli_select_db($con, 'carrental');

$email = $_POST['email'];
$password = $_POST['password'];



if ($email=="admin@admin" && $password=="admin") {
	$_SESSION['email'] = $email;
	header('location:admin.php');

}
else{
$q = " select * from users  where email = '$email' && password = '$password' ";

$result = mysqli_query($con, $q);

$num = mysqli_num_rows($result);

if($num == 1){
	
	$_SESSION['email'] = $email;
	header('location:findcar.php');


}else{

	header('location:index.php');
}


}
?>