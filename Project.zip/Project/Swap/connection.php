<?php
	
	$test=mysqli_connect("localhost","root","","carrental");
	if (!$test) {
		echo "connection failed";
	}
	
?>
