<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/ca.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/ca.css">
	<title></title>
</head>
<body>
	<header style="background-color: #f5f5f5">
		<div class="form" style="width: 500px;margin-left: 420px;margin-top: 50px">
		<div class="title">
		<h1><center>Create new account</center></h1>
		<hr>
		<div class="side"></div>
		<div id="main">
	    <form action="signup.php" method="POST">
  <div class="form-row"> 
    <div class="form-group col-md-6">
      <label for="inputEmail4">Email</label>
      <input type="email" name="email" class="form-control" id="inputEmail4" placeholder="Email">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Password</label>
      <input type="password" name="password" class="form-control" id="inputPassword4" placeholder="Password">
    </div>
  </div>
  <div class="form-group">
    <label for="inpu<dtAddress">Address</label>
    <input type="text" name="address" class="form-control" id="inputAddress" placeholder="Building name , Road , Area">
  </div>
  <div class="form-group">
    <label for="inputAddress2">Address 2</label>
    <input type="text" name="address2" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor">
  </div>
 <div class="form-group">
   <label for="inputMobile Number">Mobile Number</label>
   <input for="number" name="mobilenumber" class="form-control" id="Mobile Number" placeholder="Enter mobile number">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputCity">City</label>
      <input type="text" name="city" class="form-control" id="inputCity">
    </div>
    <div class="form-group col-md-4">
      <label for="inputState">State</label><br>
      <label for="inputZip">Maharashtra*</label>
    </div>
    <div class="form-group col-md-2">
      <label for="inputZip">Zip</label>
      <input type="text" name="zip" class="form-control" id="inputZip">
    </div>
  </div>
  <div class="form-group">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        By clicking this , you <br>agree all terms and conditions.
      </label>
    </div>
  </div><center>
  <input type="submit" value="submit" name="submit" class="btn btn-primary"></center>
</form>
</div>
	</header>

</body>
</html>