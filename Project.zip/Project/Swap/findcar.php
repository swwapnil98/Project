<?php

session_start();
if(!isset($_SESSION['email'])){
header('location:index.php');
}


?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/findcar.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body bgcolor="#ebedf0">
	<div class="body">
	<header>
		<div class="title">
		<h1><center>Find your car</center></h1>
		<hr>
		<div class="side"></div>
	<div id="main" style="width: 500px;background-color: #586f7f;padding: 10px;">
		<form method="POST" action="findcar1.php">
		Pick-up address &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp : &nbsp<input type="address" name="paddress" placeholder="Enter your address"><br><br>
        
        select pickup date &nbsp &nbsp &nbsp &nbsp : &nbsp<input type="date" name="pdate" placeholder="dd//mm//yyyy"><br><br>	
        	
       
       	Drop address &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp : &nbsp<input type="address" name="daddress" placeholder="Enter your addresss"><br><br>
       	select select drop date &nbsp: &nbsp<input type="date" name="ddate" placeholder="dd//mm//yyyy"><br><br>
       	<center>
		</center>
	</div>
	</header>
	</div>
<div class="cars">
	<table align="center" cellpadding="100">

		<tr><td>
	<div class="card" style="width: 18rem;height: 23rem;">
  <img class="card-img-top" src="SwiftDzire.jpg" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Swift Desire</h5>
    <p class="card-text">Seats : 6 <br> Price : Rs.2500 /day </p>
    <input type="radio" name="book" value="Swift Desire"> <-select here
  </div>
</div>
</td>
<td style="margin-left: 10px;">
  <div class="card" style="width: 18rem; height: 23rem;">
  <img class="card-img-top" src="SuzukiErtiga.jpg" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Suzuki Ertiga</h5>
    <p class="card-text">Seats : 7 <br> Price : Rs.3000 /day </p>
    <input type="radio" name="book" value="Suziki Ertiga"> <-select here
  </div>
</div>
</td>

<td>
  <div class="card" style="width: 18rem;height: 23rem;">
  <img class="card-img-top" src="ToyotaCorolla.jpg" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Toyota Corolla</h5>
    <p class="card-text">Sests : 5 <br> Price : Rs.4000 /day </p>
    <input type="radio" name="book" value="Toyota corolla"> <-select here
  </div>
</div>
</td>

<td>
  <div class="card" style="width: 18rem;height: 23rem;">
  <img class="card-img-top" src="HondaAmaze.jpg" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Honda Amaze</h5>
    <p class="card-text">Sests : 5 <br> price : Rs.3000 /day </p>
    <input type="radio" name="book" value="Honda Amaze"> <-select here
  </div>
</div>
</td>
  </tr>
</table>

</div>
<center><br>
<input class="btn btn-lg btn-primary btn-block" value="submit" type="submit" style="width: 100px;"></center> <br> <br>
</form>
<center>
<form action="logout.php"><input type="submit" value="logout" name="logout" class="btn btn-primary"></form></center>
</div>
</body>
</html>